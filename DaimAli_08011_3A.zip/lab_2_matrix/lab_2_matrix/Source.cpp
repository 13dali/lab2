/*
#include<iostream>
#include <conio.h>
#include <vector>
using namespace std;

void mat_mul(const vector<vector<int> >&a, int row_a,
const vector<vector<int> >&b, int row_b,
vector<vector<int> >&c)
{
for (int i = 0; i < row_a; i++)
for (int j = 0; j < 4; j++)
for (int k = 0; k < row_b; k++)
c[i][j] += a[i][k] * b[k][j];
}

int main()
{
vector<vector<int> > a(2, vector<int>(3));
vector<vector<int> > b(3, vector<int>(4));
vector<vector<int> > c(2, vector<int>(4));

a[0][0] = 6;  a[0][1] = 5;  a[0][2] = -2;
a[1][0] = -1; a[1][1] = -4; a[1][2] = 0;
b[0][0] = 6;  b[0][1] = 1;  b[0][2] = 7;  b[0][3] = 3;
b[1][0] = 2;  b[1][1] = 4;  b[1][2] = -1; b[1][3] = 5;
b[2][0] = 8;  b[2][1] = 9;  b[2][2] = 10; b[2][3] = 11;

int row_a = 2;
int row_b = 3;

mat_mul(a, row_a, b, row_b, c);


for (int j = 0; j < 2; j++){
cout << "" << endl;
for (int k = 0; k < 4; k++)
cout << c[j][k]<<"	";
}
//
//c = {
//30   8  17   21
//-14 -17  -3  -23
//}

system("pause");
return 0;
}
*/

#include <iostream>
#include <conio.h>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>
#include <cmath>

using namespace std;

int minDim = 1;
int n = 3;


class matrixMultiplication{

public:
	void iterativeCheck(vector< vector<int> > A,
		vector< vector<int> > B,
		vector< vector<int> > &C, int n) {
		for (int i = 0; i < n; i++) {
			for (int k = 0; k < n; k++) {
				for (int j = 0; j < n; j++) {
					C[i][j] += A[i][k] * B[k][j];
				}
			}
		}
	}

	void strassen_multiply(vector< vector<int> > &A,
		vector< vector<int> > &B,
		vector< vector<int> > &C, int tam) {
		if (tam <= minDim) {
			iterativeCheck(A, B, C, tam);
			return;
		}

		// other cases are treated here:
		else {
			int newTam = tam / 2;
			vector<int> inner(newTam);
			vector< vector<int> >
				a11(newTam, inner), a12(newTam, inner), a21(newTam, inner), a22(newTam, inner),
				b11(newTam, inner), b12(newTam, inner), b21(newTam, inner), b22(newTam, inner),
				c11(newTam, inner), c12(newTam, inner), c21(newTam, inner), c22(newTam, inner),
				p1(newTam, inner), p2(newTam, inner), p3(newTam, inner), p4(newTam, inner),
				p5(newTam, inner), p6(newTam, inner), p7(newTam, inner),
				aResult(newTam, inner), bResult(newTam, inner);

			int i, j;

			//dividing the matrices in 4 sub-matrices:
			for (i = 0; i < newTam; i++) {
				for (j = 0; j < newTam; j++) {
					a11[i][j] = A[i][j];
					a12[i][j] = A[i][j + newTam];
					a21[i][j] = A[i + newTam][j];
					a22[i][j] = A[i + newTam][j + newTam];

					b11[i][j] = B[i][j];
					b12[i][j] = B[i][j + newTam];
					b21[i][j] = B[i + newTam][j];
					b22[i][j] = B[i + newTam][j + newTam];
				}
			}

			// Calculating p1 to p7:

			add(a11, a22, aResult, newTam); // a11 + a22
			add(b11, b22, bResult, newTam); // b11 + b22
			strassen_multiply(aResult, bResult, p1, newTam); // p1 = (a11+a22) * (b11+b22)

			add(a21, a22, aResult, newTam); // a21 + a22
			strassen_multiply(aResult, b11, p2, newTam); // p2 = (a21+a22) * (b11)

			minus(b12, b22, bResult, newTam); // b12 - b22
			strassen_multiply(a11, bResult, p3, newTam); // p3 = (a11) * (b12 - b22)

			minus(b21, b11, bResult, newTam); // b21 - b11
			strassen_multiply(a22, bResult, p4, newTam); // p4 = (a22) * (b21 - b11)

			add(a11, a12, aResult, newTam); // a11 + a12
			strassen_multiply(aResult, b22, p5, newTam); // p5 = (a11+a12) * (b22)   

			minus(a21, a11, aResult, newTam); // a21 - a11
			add(b11, b12, bResult, newTam); // b11 + b12
			strassen_multiply(aResult, bResult, p6, newTam); // p6 = (a21-a11) * (b11+b12)

			minus(a12, a22, aResult, newTam); // a12 - a22
			add(b21, b22, bResult, newTam); // b21 + b22
			strassen_multiply(aResult, bResult, p7, newTam); // p7 = (a12-a22) * (b21+b22)

			// calculating c21, c21, c11 e c22:

			add(p3, p5, c12, newTam); // c12 = p3 + p5
			add(p2, p4, c21, newTam); // c21 = p2 + p4

			add(p1, p4, aResult, newTam); // p1 + p4
			add(aResult, p7, bResult, newTam); // p1 + p4 + p7
			minus(bResult, p5, c11, newTam); // c11 = p1 + p4 - p5 + p7

			add(p1, p3, aResult, newTam); // p1 + p3
			add(aResult, p6, bResult, newTam); // p1 + p3 + p6
			minus(bResult, p2, c22, newTam); // c22 = p1 + p3 - p2 + p6

			// Grouping the results obtained in a single matrix:
			for (i = 0; i < newTam; i++) {
				for (j = 0; j < newTam; j++) {
					C[i][j] = c11[i][j];
					C[i][j + newTam] = c12[i][j];
					C[i + newTam][j] = c21[i][j];
					C[i + newTam][j + newTam] = c22[i][j];
				}
			}
		}
	}

	unsigned int next(int n) {
		return pow(2, int(ceil(log2(n))));
	}

	void strassen(vector< vector<int> > &A,
		vector< vector<int> > &B,
		vector< vector<int> > &C, unsigned int n) {
		//unsigned int n = tam;
		unsigned int m = next(n);
		vector<int> inner(m);
		vector< vector<int> > APrep(m, inner), BPrep(m, inner), CPrep(m, inner);

		for (unsigned int i = 0; i < n; i++) {
			for (unsigned int j = 0; j < n; j++) {
				APrep[i][j] = A[i][j];
				BPrep[i][j] = B[i][j];
			}
		}

		strassen_multiply(APrep, BPrep, CPrep, m);
		for (unsigned int i = 0; i < n; i++) {
			for (unsigned int j = 0; j < n; j++) {
				C[i][j] = CPrep[i][j];
			}
		}
	}

	void add(vector< vector<int> > &A,
		vector< vector<int> > &B,
		vector< vector<int> > &C, int tam) {
		int i, j;

		for (i = 0; i < tam; i++) {
			for (j = 0; j < tam; j++) {
				C[i][j] = A[i][j] + B[i][j];
			}
		}
	}

	void minus(vector< vector<int> > &A,
		vector< vector<int> > &B,
		vector< vector<int> > &C, int tam) {
		int i, j;

		for (i = 0; i < tam; i++) {
			for (j = 0; j < tam; j++) {
				C[i][j] = A[i][j] - B[i][j];
			}
		}
	}

	void display(vector< vector<int> > matrix, int n) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (j != 0) {
					cout << "\t";
				}
				cout << matrix[i][j];
			}
			cout << endl;
		}
	}

	void iterative_multiply(const vector<vector<int> >&a, int row_a,
		const vector<vector<int> >&b, int row_b, int col_b,
		vector<vector<int> >&c)
	{
		for (int i = 0; i < row_a; i++)
		for (int j = 0; j < col_b; j++)
		for (int k = 0; k < row_b; k++)
			c[i][j] += a[i][k] * b[k][j];
	}
};

class unitTesting{

public:
	bool testMatrix(vector< vector<int> > mat1, vector< vector<int> > mat2, vector< vector<int> > expectedResult){
		vector<int> inner(n);
		vector< vector<int> > iterativeRetun(n, inner);
		vector< vector<int> > strassen_multiplyetun(n, inner);

		matrixMultiplication matObject;

		matObject.strassen(mat1, mat2, iterativeRetun, n);
		matObject.iterative_multiply(mat1, n, mat2, n, n, strassen_multiplyetun);

		//positive test
		if (strassen_multiplyetun == iterativeRetun)
			return true;
		else
			return false;
	}


};

int main(int argc, char* argv[]) {
	matrixMultiplication mat1;
	unitTesting unitObject;
	n = 3;
	vector<int> inner(n);
	vector< vector<int> > A(n, inner), B(n, inner), C(n, inner), c(n, inner);
	vector< vector<int> > expectedResult(n, inner);


	A[0][0] = 6;  A[0][1] = 5;  A[0][2] = -2;
	A[1][0] = -1; A[1][1] = -4; A[1][2] = 0;
	A[2][0] = -1; A[2][1] = -4; A[2][2] = 0;

	B[0][0] = 6;  B[0][1] = 1;  B[0][2] = 7;
	B[1][0] = 2;  B[1][1] = 4;  B[1][2] = -1;
	B[2][0] = 8;  B[2][1] = 9;  B[2][2] = 10;

	expectedResult[0][0] = 30;  expectedResult[0][1] = 8;  expectedResult[0][2] = 17;
	expectedResult[1][0] = -14;  expectedResult[1][1] = -17;  expectedResult[1][2] = -3;
	expectedResult[2][0] = -14;  expectedResult[2][1] = -17;  expectedResult[2][2] = -3;

	mat1.strassen(A, B, C, n);
	cout << "\nstrassen's algorithm result is:-\n";
	mat1.display(C, n);
	cout << "\niterative method result is:- \n" << endl;

	mat1.iterative_multiply(A, n, B, n, n, c);
	mat1.display(c, n);

	bool check = unitObject.testMatrix(A, B, expectedResult);
	cout << "\nNow,checking the results by using unit testing" << endl;
	if (check == true)
		cout << "\nGreat!!!!! expected output is matched.." << endl;
	else
		cout << "Test failed" << endl;
	system("pause");
	return 0;
}